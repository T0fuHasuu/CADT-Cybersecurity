#!/bin/bash

# start mongodb
mongod --fork --logpath /var/log/mongodb.log --dbpath /data/db --config /etc/mongod.conf

# wait until mongodb is ready
while [[ RET -ne 0 ]]; do
  echo "=> Waiting for confirmation of MongoDB service startup"
  sleep 5
  mongosh admin --eval "help" >/dev/null 2>&1
  RET=$?
done

# set DB variables "values retrieved from /app/.env"
DB_USER=$(grep DB_USER /app/.env | cut -d '"' -f2)
DB_PASS=$(grep DB_PASS /app/.env | cut -d '"' -f2)

# set up the database & user
mongosh <<EOF
use admin
db.createUser({
  user: '$DB_USER',
  pwd: '$DB_PASS',
  roles: [
    {
      role: 'readWrite',
      db: 'academy'
    }
  ]
})
EOF

# reset/drop db if it exists 'to avoid re-importing data on container restarts'
mongosh <<EOF
use academy
db.dropDatabase()
EOF

# import all json files in /tmp/db to their respective collections
DB_FILES="/tmp/db/*.json"
for file in $DB_FILES; do
  filename=$(basename -- "$file")
  collection="${filename%.*}"
  mongoimport -d 'academy' -c "$collection" --file="$file" --jsonArray
done
