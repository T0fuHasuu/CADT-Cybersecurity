package com.selector.hardcodedsecret.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.selector.hardcodedsecret.R;

public final class ListItemLayoutBinding implements ViewBinding {
    public final ImageButton btnDelete;
    public final CheckBox checkBoxTask;
    private final LinearLayout rootView;
    public final TextView textNumber;
    public final TextView textTask;

    private ListItemLayoutBinding(LinearLayout linearLayout, ImageButton imageButton, CheckBox checkBox, TextView textView, TextView textView2) {
        this.rootView = linearLayout;
        this.btnDelete = imageButton;
        this.checkBoxTask = checkBox;
        this.textNumber = textView;
        this.textTask = textView2;
    }

    public LinearLayout getRoot() {
        return this.rootView;
    }

    public static ListItemLayoutBinding inflate(LayoutInflater layoutInflater) {
        return inflate(layoutInflater, (ViewGroup) null, false);
    }

    public static ListItemLayoutBinding inflate(LayoutInflater layoutInflater, ViewGroup viewGroup, boolean z) {
        View inflate = layoutInflater.inflate(R.layout.list_item_layout, viewGroup, false);
        if (z) {
            viewGroup.addView(inflate);
        }
        return bind(inflate);
    }

    public static ListItemLayoutBinding bind(View view) {
        int i = R.id.btnDelete;
        ImageButton imageButton = (ImageButton) ViewBindings.findChildViewById(view, i);
        if (imageButton != null) {
            i = R.id.checkBoxTask;
            CheckBox checkBox = (CheckBox) ViewBindings.findChildViewById(view, i);
            if (checkBox != null) {
                i = R.id.textNumber;
                TextView textView = (TextView) ViewBindings.findChildViewById(view, i);
                if (textView != null) {
                    i = R.id.textTask;
                    TextView textView2 = (TextView) ViewBindings.findChildViewById(view, i);
                    if (textView2 != null) {
                        return new ListItemLayoutBinding((LinearLayout) view, imageButton, checkBox, textView, textView2);
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i)));
    }
}
