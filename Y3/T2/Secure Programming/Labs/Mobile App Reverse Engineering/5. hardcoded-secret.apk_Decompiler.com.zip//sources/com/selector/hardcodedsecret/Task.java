package com.selector.hardcodedsecret;

public class Task {
    private boolean completed = false;
    private String description;

    public Task(String str) {
        this.description = str;
    }

    public String getDescription() {
        return this.description;
    }

    public boolean isCompleted() {
        return this.completed;
    }

    public void setCompleted(boolean z) {
        this.completed = z;
    }
}
