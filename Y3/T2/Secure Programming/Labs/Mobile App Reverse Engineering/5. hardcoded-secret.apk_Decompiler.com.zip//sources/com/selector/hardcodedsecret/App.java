package com.selector.hardcodedsecret;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ListView;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;

public class App extends AppCompatActivity {
    private TaskAdapter adapter;
    private EditText editTextTask;
    private ListView listViewTasks;
    private ArrayList<Task> taskList;

    /* access modifiers changed from: protected */
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_app);
        this.editTextTask = (EditText) findViewById(R.id.editTextTask);
        this.listViewTasks = (ListView) findViewById(R.id.listViewTasks);
        this.taskList = new ArrayList<>();
        TaskAdapter taskAdapter = new TaskAdapter(this, this.taskList);
        this.adapter = taskAdapter;
        this.listViewTasks.setAdapter(taskAdapter);
    }

    public void addTask(View view) {
        String trim = this.editTextTask.getText().toString().trim();
        if (!trim.isEmpty()) {
            this.taskList.add(new Task(trim));
            this.adapter.notifyDataSetChanged();
            this.editTextTask.getText().clear();
        }
    }
}
