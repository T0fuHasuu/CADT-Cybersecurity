package com.selector.hardcodedsecret.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.RelativeLayout;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.selector.hardcodedsecret.R;

public final class ActivityAppBinding implements ViewBinding {
    public final Button buttonAdd;
    public final EditText editTextTask;
    public final ListView listViewTasks;
    private final RelativeLayout rootView;

    private ActivityAppBinding(RelativeLayout relativeLayout, Button button, EditText editText, ListView listView) {
        this.rootView = relativeLayout;
        this.buttonAdd = button;
        this.editTextTask = editText;
        this.listViewTasks = listView;
    }

    public RelativeLayout getRoot() {
        return this.rootView;
    }

    public static ActivityAppBinding inflate(LayoutInflater layoutInflater) {
        return inflate(layoutInflater, (ViewGroup) null, false);
    }

    public static ActivityAppBinding inflate(LayoutInflater layoutInflater, ViewGroup viewGroup, boolean z) {
        View inflate = layoutInflater.inflate(R.layout.activity_app, viewGroup, false);
        if (z) {
            viewGroup.addView(inflate);
        }
        return bind(inflate);
    }

    public static ActivityAppBinding bind(View view) {
        int i = R.id.buttonAdd;
        Button button = (Button) ViewBindings.findChildViewById(view, i);
        if (button != null) {
            i = R.id.editTextTask;
            EditText editText = (EditText) ViewBindings.findChildViewById(view, i);
            if (editText != null) {
                i = R.id.listViewTasks;
                ListView listView = (ListView) ViewBindings.findChildViewById(view, i);
                if (listView != null) {
                    return new ActivityAppBinding((RelativeLayout) view, button, editText, listView);
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i)));
    }
}
