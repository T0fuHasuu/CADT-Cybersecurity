package com.selector.hardcodedsecret;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    public native int getAuthenticationKey();

    static {
        System.loadLibrary("hardcodedsecret");
    }

    /* access modifiers changed from: protected */
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_main);
        final EditText editText = (EditText) findViewById(R.id.authenticationKey);
        ((Button) findViewById(R.id.loginbtn)).setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                try {
                    if (Integer.parseInt(editText.getText().toString()) == MainActivity.this.getAuthenticationKey()) {
                        Toast.makeText(MainActivity.this, "Valid Authentication Key!", 0).show();
                        MainActivity.this.startActivity(new Intent(MainActivity.this, App.class));
                        return;
                    }
                    Toast.makeText(MainActivity.this, "Invalid Authentication Key!", 0).show();
                } catch (NumberFormatException unused) {
                    Toast.makeText(MainActivity.this, "Please enter a valid integer for the Authentication Key!", 0).show();
                }
            }
        });
    }
}
