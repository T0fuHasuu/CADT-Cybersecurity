package com.selector.locateme;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;

public class App extends AppCompatActivity {
    private TextView UserID;
    private TaskAdapter adapter;
    private EditText editTextTask;
    private ListView listViewTasks;
    private ArrayList<Task> taskList;

    /* access modifiers changed from: protected */
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.app_activity);
        this.UserID = (TextView) findViewById(R.id.UserID);
        this.editTextTask = (EditText) findViewById(R.id.editTextTask);
        this.listViewTasks = (ListView) findViewById(R.id.listViewTasks);
        this.taskList = new ArrayList<>();
        TaskAdapter taskAdapter = new TaskAdapter(this, this.taskList);
        this.adapter = taskAdapter;
        this.listViewTasks.setAdapter(taskAdapter);
        this.UserID.setText("UserID : " + AESforGPS.DecryptAES("Hx2xWh8zXOOxP8TO3/l2fQ==", "0123456789abcdef".getBytes(), "1234567890abcdef".getBytes()));
    }

    public void addTask(View view) {
        String trim = this.editTextTask.getText().toString().trim();
        if (!trim.isEmpty()) {
            this.taskList.add(new Task(trim));
            this.adapter.notifyDataSetChanged();
            this.editTextTask.getText().clear();
        }
    }
}
