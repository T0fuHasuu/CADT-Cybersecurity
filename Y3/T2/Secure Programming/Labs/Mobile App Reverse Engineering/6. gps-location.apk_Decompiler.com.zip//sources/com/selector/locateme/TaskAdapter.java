package com.selector.locateme;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.ImageButton;
import android.widget.TextView;
import java.util.ArrayList;

public class TaskAdapter extends ArrayAdapter<Task> {
    private Context mContext;
    /* access modifiers changed from: private */
    public ArrayList<Task> mTaskList;

    public TaskAdapter(Context context, ArrayList<Task> arrayList) {
        super(context, 0, arrayList);
        this.mContext = context;
        this.mTaskList = arrayList;
    }

    public View getView(final int i, View view, ViewGroup viewGroup) {
        if (view == null) {
            view = LayoutInflater.from(this.mContext).inflate(R.layout.list_item_layout, viewGroup, false);
        }
        Task task = (Task) getItem(i);
        ((TextView) view.findViewById(R.id.textNumber)).setText(String.valueOf(i + 1));
        ((TextView) view.findViewById(R.id.textTask)).setText(task.getDescription());
        ((CheckBox) view.findViewById(R.id.checkBoxTask)).setChecked(task.isCompleted());
        ((ImageButton) view.findViewById(R.id.btnDelete)).setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                TaskAdapter.this.mTaskList.remove(i);
                TaskAdapter.this.notifyDataSetChanged();
            }
        });
        return view;
    }
}
