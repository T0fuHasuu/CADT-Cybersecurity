package com.selector.locateme;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class failed extends AppCompatActivity {
    /* access modifiers changed from: protected */
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.failed_activity);
        ((ImageView) findViewById(R.id.imageView)).setImageResource(R.drawable.ic_location_error);
        ((TextView) findViewById(R.id.messageTextView)).setText("The app is not available in your region");
    }
}
