package com.selector.locateme;

import android.app.Activity;
import android.content.Intent;
import android.location.Location;
import android.os.Bundle;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;

public class MainActivity extends AppCompatActivity {
    private static final int PERMISSION_REQUEST_CODE = 100;
    private FusedLocationProviderClient fusedLocationClient;

    /* access modifiers changed from: protected */
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_main);
        this.fusedLocationClient = LocationServices.getFusedLocationProviderClient((Activity) this);
        if (checkLocationPermission()) {
            requestLocation();
        } else {
            requestLocationPermission();
        }
    }

    private boolean checkLocationPermission() {
        return ContextCompat.checkSelfPermission(this, "android.permission.ACCESS_FINE_LOCATION") == 0;
    }

    private void requestLocationPermission() {
        ActivityCompat.requestPermissions(this, new String[]{"android.permission.ACCESS_FINE_LOCATION"}, 100);
    }

    private void requestLocation() {
        if (ActivityCompat.checkSelfPermission(this, "android.permission.ACCESS_FINE_LOCATION") == 0 || ActivityCompat.checkSelfPermission(this, "android.permission.ACCESS_COARSE_LOCATION") == 0) {
            this.fusedLocationClient.getLastLocation().addOnCompleteListener((Activity) this, new OnCompleteListener<Location>() {
                public void onComplete(Task<Location> task) {
                    if (!task.isSuccessful() || task.getResult() == null) {
                        Toast.makeText(MainActivity.this, "Unable to get location", 0).show();
                        return;
                    }
                    Location result = task.getResult();
                    double latitude = result.getLatitude();
                    double longitude = result.getLongitude();
                    if (latitude < -75.751d || latitude > -74.751d || longitude < -0.5714d || longitude > 0.4286d) {
                        MainActivity.this.startActivity(new Intent(MainActivity.this, failed.class));
                        return;
                    }
                    MainActivity.this.startActivity(new Intent(MainActivity.this, App.class));
                }
            });
        }
    }

    public void onRequestPermissionsResult(int i, String[] strArr, int[] iArr) {
        super.onRequestPermissionsResult(i, strArr, iArr);
        if (i != 100) {
            return;
        }
        if (iArr.length <= 0 || iArr[0] != 0) {
            Toast.makeText(this, "Permission denied", 0).show();
        } else {
            requestLocation();
        }
    }
}
