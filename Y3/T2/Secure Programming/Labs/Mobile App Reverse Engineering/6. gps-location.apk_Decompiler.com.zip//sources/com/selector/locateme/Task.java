package com.selector.locateme;

public class Task {
    private boolean completed = false;
    private String description;

    public String getDescription() {
        return this.description;
    }

    public boolean isCompleted() {
        return this.completed;
    }

    public void setCompleted(boolean z) {
        this.completed = z;
    }

    public Task(String str) {
        this.description = str;
    }
}
