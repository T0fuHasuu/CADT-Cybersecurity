package com.selector.checkdb;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {
    private static final String COLUMN_ID = "SessionID";
    private static final String COLUMN_USERNAME = "username";
    private static final String CREATE_TABLE = "CREATE TABLE IF NOT EXISTS users (username TEXT PRIMARY KEY,verify INT ,SessionID TEXT)";
    private static final String DATABASE_NAME = "login.db";
    private static final int DATABASE_VERSION = 1;
    private static final String TABLE_NAME = "users";
    private static final String VERIFY = "verify";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, (SQLiteDatabase.CursorFactory) null, 1);
    }

    public void onCreate(SQLiteDatabase sQLiteDatabase) {
        sQLiteDatabase.execSQL(CREATE_TABLE);
    }

    public void onUpgrade(SQLiteDatabase sQLiteDatabase, int i, int i2) {
        sQLiteDatabase.execSQL("DROP TABLE IF EXISTS users");
        onCreate(sQLiteDatabase);
    }

    public boolean isHashExists() {
        SQLiteDatabase readableDatabase = getReadableDatabase();
        Cursor query = readableDatabase.query(TABLE_NAME, new String[]{COLUMN_ID, VERIFY}, (String) null, (String[]) null, (String) null, (String) null, (String) null);
        boolean z = query != null && query.moveToFirst();
        if (query != null) {
            query.close();
        }
        readableDatabase.close();
        return z;
    }

    public boolean isVerified() {
        SQLiteDatabase readableDatabase = getReadableDatabase();
        Cursor query = readableDatabase.query(TABLE_NAME, new String[]{COLUMN_ID, VERIFY}, (String) null, (String[]) null, (String) null, (String) null, (String) null);
        boolean z = false;
        boolean z2 = query != null && query.moveToFirst();
        if (!z2 || query.getInt(1) != 0) {
            z = z2;
        }
        if (query != null) {
            query.close();
        }
        readableDatabase.close();
        return z;
    }

    public void saveID(String str, String str2) {
        SQLiteDatabase writableDatabase = getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COLUMN_USERNAME, str2);
        contentValues.put(COLUMN_ID, str);
        contentValues.put(VERIFY, 0);
        writableDatabase.insertWithOnConflict(TABLE_NAME, (String) null, contentValues, 5);
        writableDatabase.close();
    }
}
