package com.selector.checkdb;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {
    private Button buttonLogin;
    private DatabaseHelper dbHelper;
    private EditText editTextUsername;

    /* access modifiers changed from: protected */
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_login);
        this.editTextUsername = (EditText) findViewById(R.id.username);
        this.buttonLogin = (Button) findViewById(R.id.loginbtn);
        this.dbHelper = new DatabaseHelper(this);
        this.buttonLogin.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                LoginActivity.this.login();
            }
        });
        checkLoginStatus();
    }

    private void checkLoginStatus() {
        try {
            if (!this.dbHelper.isHashExists()) {
                AletMsgbox("User record not found. You must register");
            } else if (!this.dbHelper.isVerified()) {
                AletMsgbox("Wait until your account is verified by the administrator");
            } else {
                openMainActivity();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /* access modifiers changed from: private */
    public void login() {
        try {
            String trim = this.editTextUsername.getText().toString().trim();
            if (trim.length() < 3) {
                AletMsgbox("Username must be at least 3 characters");
                return;
            }
            if (!this.dbHelper.isHashExists()) {
                this.dbHelper.saveID("670269c5dcd257dec857b0106ce", trim);
            }
            checkLoginStatus();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void AletMsgbox(String str) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle((CharSequence) "Alert!");
        builder.setMessage((CharSequence) str);
        builder.setPositiveButton((CharSequence) "OK", (DialogInterface.OnClickListener) new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialogInterface, int i) {
            }
        });
        builder.show();
    }

    private void openMainActivity() {
        try {
            startActivity(new Intent(this, ChatApp.class));
            finish();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
