package com.selector.checkdb;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;

public class ChatApp extends AppCompatActivity {
    private static final String TAG = "ChatApp";
    private boolean isfirst = true;
    private ArrayAdapter<String> messageAdapter;
    /* access modifiers changed from: private */
    public EditText messageEditText;
    private ListView messageListView;
    private ArrayList<String> messages;
    private Button sendButton;

    /* access modifiers changed from: protected */
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_main);
        this.messageListView = (ListView) findViewById(R.id.messageListView);
        this.messageEditText = (EditText) findViewById(R.id.messageEditText);
        this.sendButton = (Button) findViewById(R.id.sendButton);
        this.messages = new ArrayList<>();
        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<>(this, 17367043, this.messages);
        this.messageAdapter = arrayAdapter;
        this.messageListView.setAdapter(arrayAdapter);
        ((TextView) findViewById(R.id.usernameTextView)).setText(getIntent().getStringExtra("USERNAME"));
        this.sendButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                ChatApp.this.sendMessage(ChatApp.this.messageEditText.getText().toString().trim());
            }
        });
        if (this.isfirst) {
            sendMessage(AESforDB.DecryptAES("pCFdXlNcKQ91QRMDQfAQfKPZ0BoaZHM42pLHBbHWz+p+Jju/lTD6tePglxmS5ZmV", "0123456789abcdef".getBytes(), "1234567890abcdef".getBytes()));
            this.isfirst = false;
        }
    }

    /* access modifiers changed from: private */
    public void sendMessage(String str) {
        if (!str.isEmpty()) {
            this.messages.add(str);
            this.messageAdapter.notifyDataSetChanged();
            this.messageEditText.getText().clear();
        }
    }
}
