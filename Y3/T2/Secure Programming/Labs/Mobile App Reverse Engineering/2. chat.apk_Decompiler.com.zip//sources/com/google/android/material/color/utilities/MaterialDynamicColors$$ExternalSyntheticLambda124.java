package com.google.android.material.color.utilities;

import java.util.function.Function;

/* compiled from: D8$$SyntheticClass */
public final /* synthetic */ class MaterialDynamicColors$$ExternalSyntheticLambda124 implements Function {
    public final Object apply(Object obj) {
        return MaterialDynamicColors.lambda$outlineVariant$45((DynamicScheme) obj);
    }
}
