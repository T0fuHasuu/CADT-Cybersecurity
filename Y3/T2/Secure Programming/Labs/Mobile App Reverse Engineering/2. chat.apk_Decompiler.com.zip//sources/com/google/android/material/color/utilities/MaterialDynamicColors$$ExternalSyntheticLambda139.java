package com.google.android.material.color.utilities;

import java.util.function.Function;

/* compiled from: D8$$SyntheticClass */
public final /* synthetic */ class MaterialDynamicColors$$ExternalSyntheticLambda139 implements Function {
    public final Object apply(Object obj) {
        return MaterialDynamicColors.lambda$onTertiaryFixed$138((DynamicScheme) obj);
    }
}
