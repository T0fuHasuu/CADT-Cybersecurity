package com.google.android.material.color.utilities;

import java.util.function.Function;

/* compiled from: D8$$SyntheticClass */
public final /* synthetic */ class MaterialDynamicColors$$ExternalSyntheticLambda69 implements Function {
    public final /* synthetic */ MaterialDynamicColors f$0;

    public /* synthetic */ MaterialDynamicColors$$ExternalSyntheticLambda69(MaterialDynamicColors materialDynamicColors) {
        this.f$0 = materialDynamicColors;
    }

    public final Object apply(Object obj) {
        return this.f$0.m66lambda$onSecondaryContainer$78$comgoogleandroidmaterialcolorutilitiesMaterialDynamicColors((DynamicScheme) obj);
    }
}
