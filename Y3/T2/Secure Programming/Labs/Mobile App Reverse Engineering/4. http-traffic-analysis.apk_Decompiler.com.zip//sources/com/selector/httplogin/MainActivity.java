package com.selector.httplogin;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.button.MaterialButton;

public class MainActivity extends AppCompatActivity {
    private MaterialButton loginButton;
    /* access modifiers changed from: private */
    public EditText passwordEditText;
    /* access modifiers changed from: private */
    public EditText usernameEditText;

    /* access modifiers changed from: protected */
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_main);
        this.usernameEditText = (EditText) findViewById(R.id.username);
        this.passwordEditText = (EditText) findViewById(R.id.password);
        MaterialButton materialButton = (MaterialButton) findViewById(R.id.loginbtn);
        this.loginButton = materialButton;
        materialButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                String obj = MainActivity.this.usernameEditText.getText().toString();
                new SendDataTask().execute(new String[]{obj, MainActivity.this.passwordEditText.getText().toString()});
                MainActivity.this.openchat(obj);
            }
        });
    }

    public void openchat(String str) {
        Intent intent = new Intent(this, ChatApp.class);
        intent.putExtra("USERNAME", str);
        startActivity(intent);
    }
}
