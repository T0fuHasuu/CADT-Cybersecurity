package com.selector.httplogin;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import kotlin.UByte;

public class BlowfishEncryption {
    public static byte[] Encrypt(String str, String str2) throws Exception {
        SecretKeySpec secretKeySpec = new SecretKeySpec(str2.getBytes(), "Blowfish");
        Cipher instance = Cipher.getInstance("Blowfish");
        instance.init(1, secretKeySpec);
        return instance.doFinal(str.getBytes());
    }

    public static String Decrypt(byte[] bArr, String str) throws Exception {
        SecretKeySpec secretKeySpec = new SecretKeySpec(str.getBytes(), "Blowfish");
        Cipher instance = Cipher.getInstance("Blowfish");
        instance.init(2, secretKeySpec);
        return new String(instance.doFinal(bArr));
    }

    public static String BytesToHex(byte[] bArr) {
        StringBuilder sb = new StringBuilder();
        for (byte b : bArr) {
            sb.append(Integer.toString((b & UByte.MAX_VALUE) + UByte.MIN_VALUE, 16).substring(1));
        }
        return sb.toString();
    }

    public static byte[] HexStringToByteArray(String str) {
        int length = str.length();
        byte[] bArr = new byte[(length / 2)];
        for (int i = 0; i < length; i += 2) {
            bArr[i / 2] = (byte) ((Character.digit(str.charAt(i), 16) << 4) + Character.digit(str.charAt(i + 1), 16));
        }
        return bArr;
    }
}
