package com.selector.httplogin;

import android.os.AsyncTask;
import android.util.Base64;
import android.util.Log;
import java.io.BufferedOutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

public class SendDataTask extends AsyncTask<String, Void, Integer> {
    private static final String TAG = "SendDataTask";

    /* access modifiers changed from: protected */
    public Integer doInBackground(String... strArr) {
        int i = 0;
        String str = strArr[0];
        String str2 = strArr[1];
        try {
            HttpURLConnection httpURLConnection = (HttpURLConnection) new URL("http://hackviser.space/").openConnection();
            httpURLConnection.setRequestMethod("POST");
            String Decrypt = BlowfishEncryption.Decrypt(BlowfishEncryption.HexStringToByteArray("e27045e453c5891e7bc075e782d048eb557fffc158effc26687b67d021c06cab648371341818d310"), "ThisIsABlowfishKey");
            httpURLConnection.setDoOutput(true);
            httpURLConnection.setRequestProperty("Content-Type", "text/plain");
            httpURLConnection.setRequestProperty("user-trace-id", Decrypt);
            httpURLConnection.setRequestProperty("Authorization", "Basic " + encodeCredentials(str, str2));
            BufferedOutputStream bufferedOutputStream = new BufferedOutputStream(httpURLConnection.getOutputStream());
            bufferedOutputStream.flush();
            bufferedOutputStream.close();
            i = httpURLConnection.getResponseCode();
            Log.d(TAG, "Response Code: " + i);
            httpURLConnection.disconnect();
        } catch (Exception e) {
            throw new RuntimeException(e);
        } catch (Exception e2) {
            Log.e(TAG, "Error: " + e2.getMessage());
        }
        return Integer.valueOf(i);
    }

    private String encodeCredentials(String str, String str2) {
        return Base64.encodeToString((str + ":" + str2).getBytes(), 2);
    }
}
