package com.selector.httplogin;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.button.MaterialButton;
import java.util.concurrent.ExecutionException;

public class MainActivity extends AppCompatActivity {
    private MaterialButton loginButton;
    /* access modifiers changed from: private */
    public EditText passwordEditText;
    /* access modifiers changed from: private */
    public EditText usernameEditText;

    /* access modifiers changed from: protected */
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_main);
        this.usernameEditText = (EditText) findViewById(R.id.username);
        this.passwordEditText = (EditText) findViewById(R.id.password);
        MaterialButton materialButton = (MaterialButton) findViewById(R.id.loginbtn);
        this.loginButton = materialButton;
        materialButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                try {
                    if (((Integer) new SendDataTask().execute(new String[]{MainActivity.this.usernameEditText.getText().toString(), MainActivity.this.passwordEditText.getText().toString()}).get()).intValue() == 200) {
                        Toast.makeText(MainActivity.this, "Login Successful", 0).show();
                        MainActivity.this.openchat("ADMIN");
                        return;
                    }
                    Toast.makeText(MainActivity.this, "Login Failed", 0).show();
                } catch (ExecutionException e) {
                    throw new RuntimeException(e);
                } catch (InterruptedException e2) {
                    throw new RuntimeException(e2);
                }
            }
        });
    }

    public void openchat(String str) {
        Intent intent = new Intent(this, ChatApp.class);
        intent.putExtra("USERNAME", str);
        startActivity(intent);
    }
}
